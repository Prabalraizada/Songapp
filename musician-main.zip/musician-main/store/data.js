// A collection of musicians where the key is the unique id
module.exports = {
  coltrane: {
    firstName: 'Arijit ',
    lastName: 'Singh',
    genre: 'Romantic',
  },

  davis: {
    firstName: 'Jubin',
    lastName: 'Nautiyal',
    genre: 'Sad',
  },

  mccartney: {
    firstName: 'Yo Yo Honey',
    lastName: 'Singh',
    genre: 'Rap',
  },

  hendrix: {
    firstName: 'Armaan',
    lastName: 'Malik',
    genre: 'Romantic',
  },

  cobain: {
    firstName: 'Ranjit',
    lastName: 'Bawa',
    genre: 'punjabi',
  },

  king: {
    firstName: 'Shreya',
    lastName: 'Ghoshal',
    genre: 'Romantic',
  },
};
